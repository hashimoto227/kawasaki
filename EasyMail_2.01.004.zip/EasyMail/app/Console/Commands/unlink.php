<?php
/**
 * シンボリックリンクの削除
 */
//unlink(dirname(__FILE__) . '/public/storage');
//unlink(dirname(__FILE__) . '/public/form_item_image');

