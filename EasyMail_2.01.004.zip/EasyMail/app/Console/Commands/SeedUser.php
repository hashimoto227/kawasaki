<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class SeedUser extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:SeedUser';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        DB::table('team_user')
          ->insert(
              [
                  'created_at' => now(),
                  'updated_at' => now(),
                  'team_id'    => 1,
                  'user_id'    => '1',
                  'role'       => 'admin',
              ]
          );

        DB::table('users')
          ->insert(
              [
                  'created_at'                => now(),
                  'updated_at'                => now(),
                  'name'                      => 'user1',
                  'email'                     => 'admin@example.com',
                  'email_verified_at'         => now(),
                  'password'                  => Hash::make('123456789'),
                  'two_factor_secret'         => null,
                  'two_factor_recovery_codes' => null,
                  'remember_token'            => 'Jp1OhtLnVHrQnBhxxgiH1tiGB3g2sRMbZ28M8J2dF8K6A4tEjB9J7x6V8Rmr',
                  'current_team_id'           => 1,
                  'profile_photo_path'        => null,
                  'login_flag'                => 1,
                  'language'                  => 'ja',
              ]
          );

        $this->info( 'Users record seeding completed successfully.' );

        return 0;
    }
}
