<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Models\User;
use App\Models\Team;
use App\Events\PluginEvent;
use App\Events\PluginEventConf;
use App\Library\Common;
use App\Rules\AdminPassword;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response as ResponseAlias;
use Illuminate\View\View;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;


class UserController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        PluginEvent::event(PluginEventConf::ADMIN_CONSTRACT_INITIALIZE, null);
        $this->middleware(['check_language', 'dash_board_menu']);
        PluginEvent::event(PluginEventConf::ADMIN_CONSTRACT_COMPLETE, null);
    }

    /**
     * Display a listing of the resource.
     *
     * @return Application|Factory|ResponseAlias|View
     */
    public function index()
    {
        PluginEvent::event(PluginEventConf::ADMIN_USER_CONTROLLER_INDEX_INITIALIZE, null);

        $data = User::whereNotIn('email', [auth()->user()->email])
                    ->with('team_user')
                    ->orderBy('created_at', 'desc')
                    ->get();
        $arg  = [
            "data"   => $data,
            'append' => require base_path() . "/config/append.php",
        ];
        $arg  = PluginEvent::event(PluginEventConf::ADMIN_USER_CONTROLLER_INDEX_JUST_BEFORE_VIEW, $arg);

        return view('admin.user.list', [
            'data'   => $arg['data'],
            'append' => $arg['append'],
            'url'    => config('app.url'),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Application|Factory|ResponseAlias|View
     */
    public function create()
    {
        PluginEvent::event(PluginEventConf::ADMIN_USER_CONTROLLER_CREATE_INITIALIZE, null);
        $arg = [
            "append" => require base_path() . "/config/append.php",
        ];
        $arg = PluginEvent::event(PluginEventConf::ADMIN_USER_CONTROLLER_CREATE_JUST_BEFORE_VIEW, $arg);

        return view('admin.user.create', [
            'append'   => $arg['append'],
            'language' => Common::lang_list(),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     *
     * @return RedirectResponse
     */
    public function store(StoreUserRequest $request)
    {
        $arg          = [
            "request"      => $request,
        ];
        $arg          = PluginEvent::event(PluginEventConf::ADMIN_USER_CONTROLLER_STORE_INITIALIZE, $arg);


        $request->merge(['password' => Hash::make($request->input('password'))]);
        $request->merge(['language' => 'ja']);

        $user = new User();

        $user->fill($request->except(['role']));
        $user->save();
        $create_user = User::find($user->id);
        $create_user->team_user()->attach(1, ['role' => $request->role]);

        $arg = [
            "forms"   => $user,
            "request" => $request,
        ];
        PluginEvent::event(PluginEventConf::ADMIN_USER_CONTROLLER_STORE_JUST_BEFORE_REDIRECT, $arg);

        return redirect()
            ->route('admin.users.index')
            ->with("message", __("admin_messages.user.user_regist_comp"));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param $id
     *
     * @return Application|Factory|ResponseAlias|View
     */
    public function edit($id)
    {

        $arg = [
            "id"     => $id,
            "append" => require base_path() . "/config/append.php",
        ];
        PluginEvent::event(PluginEventConf::ADMIN_USER_CONTROLLER_EDIT_INITIALIZE, $arg);
        $data = User::where('id', $id)->with('team_user')->first();
        $arg  = [
            "data"   => $data,
            "append" => require base_path() . "/config/append.php",
        ];

        $arg = PluginEvent::event(PluginEventConf::ADMIN_USER_CONTROLLER_EDIT_JUST_BEFORE_VIEW, $arg);
        return view('admin.user.edit', [
            'data'     => $arg['data'],
            'language' => Common::lang_list(),

        ]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param $id
     *
     * @return Application|Factory|View|void
     */
    public function update(UpdateUserRequest $request,User $user)
    {   
        $arg = [
            "id"           => $user->id,
            "request"      => $request,
        ];
        
        $arg = PluginEvent::event(PluginEventConf::ADMIN_USER_CONTROLLER_UPDATE_INITIALIZE, $arg);
        // 変更パスワードの入力がない場合は更新項目から外す。
        if (empty($request->input('password'))) {
            unset($request['password']);
        }
        else {
            $request->merge(['password' => Hash::make($request->input('password'))]);
        }

        $user->fill($request->except(['role']));
        $user->save();
        $create_user = User::find($user->id);
        $user->team_user()->detach();
        $create_user->team_user()->attach(1, ['role' => $request->role]);

        $arg = [
            "request" => $request,
            "append"  => require base_path() . "/config/append.php",
        ];
        $arg = PluginEvent::event(PluginEventConf::ADMIN_USER_CONTROLLER_UPDATE_JUST_BEFORE_VIEW, $arg);

        return redirect()
            ->route('admin.users.edit', $user->id)
            ->with("message", __("admin_messages.rew_comp"));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param $id
     *
     * @return RedirectResponse
     */
    public function destroy($id)
    {
        $delete_user = User::find($id);
        $delete_user->team_user()->detach();
        $arg = ["id" => $id];
        $arg = PluginEvent::event(PluginEventConf::ADMIN_USER_CONTROLLER_DESTROY_INITIALIZE, $arg);
        User::destroy($arg['id']);
        PluginEvent::event(PluginEventConf::ADMIN_USER_CONTROLLER_DESTROY_JUST_BEFORE_REDIRECT, $arg);

        return redirect()
            ->route('admin.users.index')
            ->with("message", __('admin_messages.delete_comp'));
    }

}
