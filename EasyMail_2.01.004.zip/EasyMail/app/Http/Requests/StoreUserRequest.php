<?php

namespace App\Http\Requests;
use App\Rules\AdminPassword;
use Illuminate\Foundation\Http\FormRequest;

class StoreUserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $validate     = [
            'name'     => ['required', 'max:255'],
            'role'     => ['required'],
            'email'    => ['required', 'email', 'max:255', 'unique:users'],
            'password' => ['required', new AdminPassword()],
          ];
        
          return $validate;
    }


    public function messages(){
        return[
            'name.required'     => __("admin_messages.user.user_name_is_required"),
            'role.required'     => __("admin_messages.user.user_role_is_required"),
            'email.required'    => __("admin_messages.user.user_email_is_required"),
            'email.email'       => __("admin_messages.user.user_check_the_email_address"),
            'password.required' => __("admin_messages.user.user_password_is_required"),
        ];
    }
}
