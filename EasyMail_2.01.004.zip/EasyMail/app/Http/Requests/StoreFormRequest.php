<?php

namespace App\Http\Requests;
use App\Events\PluginEvent;
use App\Events\PluginEventConf;
use Illuminate\Foundation\Http\FormRequest;


class StoreFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {

        $validate     = [
            'url'         => 'unique:forms',
            'name'        => 'required',
            'theme_name'  => 'required',
            'mail_title'  => 'required',
            'admin_email' => 'required|email',
          ];
        
          $arg = ['validate'=>$validate,'request'=>$this->request];
          $arg          = PluginEvent::event( PluginEventConf::ADMIN_FORM_STORE_REQUEST_RULES, $arg );
          return $arg['validate'];
       
    }

    public function messages(){
        return[
            'url.unique'           => __( "admin_messages.form.folder_duplicated" ),
        'name.required'        => __( "admin_messages.form.form_name_is_required" ),
        'theme_name.required'  => __( "admin_messages.form.theme_name_is_required" ),
        'mail_title.required'  => __( "admin_messages.form.automatic_reply_email_subject_is_required" ),
        'admin_email.required' => __( "admin_messages.form.administrator_received_email_address_is_required" ),
        'admin_email.email'    => __( "admin_messages.form.email_address_format" ),
        ];
    }
}
