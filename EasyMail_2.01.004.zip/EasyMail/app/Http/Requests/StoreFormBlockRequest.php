<?php

namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
use App\Rules\AlphabetNumHyphenUnderscore;

class StoreFormBlockRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {      
          $validate = [
            'title'     => 'required',
            'view_no'   => 'required|integer',
            'form_type' => 'required', 
          ];
          $arg          = ["validate" => $validate,'request'=>$this->request];

          if ( in_array($arg['request']->get('form_type'), [ 'text', 'number', 'email', 'password', 'tel', 'url', 'multi_select', 'radio' , 'checkbox' , 'file' , 'date' , 'datetime' , 'month'] ) ) {
            $arg['validate']+= [ 'name' =>  'required', new AlphabetNumHyphenUnderscore() ]; 
         }
         else {
           $arg['validate']+= [ 'name' =>  'nullable', new AlphabetNumHyphenUnderscore() ];
         }
          return $arg['validate'];
        }

    public function messages(){
        return[
            'title.required'      => __( "admin_messages.form_block.title_required" ),
            'name.required'       => __( "admin_messages.form_block.name_required" ),
            'view_no.required'    => __( "admin_messages.form_block.view_no_required" ),
            'view_no.numeric'     => __( "admin_messages.form_block.view_no_numeric" ),
            'form_type.required'  => __( "admin_messages.form_block.form_type_required" ),
            'name.num_alpha_dash' => __( "admin_messages.form_block.name_num_alpha_dash" ),
            'columns.integer'     => __( "admin_messages.form_block.columns_integer" ),
            'columns.between'     => __( "admin_messages.form_block.columns_between" ),
        ];
    }
}
