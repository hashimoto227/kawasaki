<?php

namespace App\Http\Requests;
use App\Rules\AdminPassword;
use Illuminate\Foundation\Http\FormRequest;


class UpdateUserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        
        $email_unique = 'unique:users,email,' .$this->request->get('email'). ',email';
        $validate     = [
            'email'    => 'required', 'email', 'max:255', $email_unique,
            'password' => 'required', new AdminPassword(),
            'name'     => 'required',
            'role'     => 'required',
          ];
         // 変更パスワードの入力がない場合はチェック項目から外す。
         if (empty($this->request->get('password'))) {
            unset($validate['password']);
        }
          return $validate;
    }


    public function messages(){
        return[
            'email.required'    => __("admin_messages.user.user_email_is_required"),
            'email.email'       => __("admin_messages.user.user_check_the_email_address"),
            'password.required' => __("admin_messages.user.user_password_is_required"),
            'name.required'     => __('admin_messages.user.user_name_is_required'),
            'role.required'     => __('admin_messages.user.user_role_is_required'),
        ];
    }
}
