<?php

namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
//デモモードの場合のみ項目の編集や新規作成ができないようにする。
class DemomodeAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next,$role)
    {
        if(!Auth::user()->hasTeamPermission(Auth::user()->currentTeam,$role, 'demo')){
            return $next($request);
        }else{
        return redirect()
          ->back()
          ->with( "message", "デモモードのため作成・編集・削除はできません" );
        }
}
}
