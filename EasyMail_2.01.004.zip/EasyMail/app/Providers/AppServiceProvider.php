<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Encryption\Encrypter;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\URL;
use App\PluginManager\EmPluginManager;
use App\DashBoard;
use Illuminate\View\View;
use App\User;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        if (!config("app.key")) {
            $key  = 'base64:' . base64_encode(Encrypter::generateKey(config('app.cipher')));
            $path = base_path() . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "app.php";
            file_put_contents($path, str_replace("'key' => env('APP_KEY','')", "'key' => '" . $key . "'", file_get_contents($path)));
            file_put_contents($path, str_replace("'key' => env('APP_KEY', '')", "'key' => '" . $key . "'", file_get_contents($path)));
            Config::set('app.key', $key);
        }
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        EmPluginManager::init();

        // 強制SSL
        // if (App::environment(['production', 'staging'])) {
        //     URL::forceScheme('https');
        // }

    }
}

