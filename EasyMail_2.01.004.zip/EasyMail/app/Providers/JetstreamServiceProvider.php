<?php

namespace App\Providers;

use App\Actions\Jetstream\AddTeamMember;
use App\Actions\Jetstream\CreateTeam;
use App\Actions\Jetstream\DeleteTeam;
use App\Actions\Jetstream\DeleteUser;
use App\Actions\Jetstream\InviteTeamMember;
use App\Actions\Jetstream\RemoveTeamMember;
use App\Actions\Jetstream\UpdateTeamName;
use Illuminate\Support\ServiceProvider;
use Laravel\Jetstream\Jetstream;

class JetstreamServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        $this->configurePermissions();

        Jetstream::createTeamsUsing(CreateTeam::class);
        Jetstream::updateTeamNamesUsing(UpdateTeamName::class);
        Jetstream::addTeamMembersUsing(AddTeamMember::class);
        Jetstream::inviteTeamMembersUsing(InviteTeamMember::class);
        Jetstream::removeTeamMembersUsing(RemoveTeamMember::class);
        Jetstream::deleteTeamsUsing(DeleteTeam::class);
        Jetstream::deleteUsersUsing(DeleteUser::class);
    }

    /**
     * Configure the roles and permissions that are available within the application.
     *
     * @return void
     */
    protected function configurePermissions()
    {
      Jetstream::role('admin', __('admin_messages.user.admin'), [//管理者
        'read',
        'create',
        'update',
        'delete',
        'admin',
        'plugin',
        'user',
        'theme',
        'language',
        'setting',
      ])->description(__('admin_messages.teams.admin_description'));

      Jetstream::role('editor', __('admin_messages.user.editor'), [//編集者
        'read',
        'create',
        'update',
        'delete',
        'editor',
        'plugin',
        // 'user',
        'theme',
        'language',
        'setting',
      ])->description(__('admin_messages.teams.editor_description'));

      Jetstream::role('general_editor', __('admin_messages.user.general_editor'), [//一般編集者
        'read',
        'create',
        'update',
        'delete',
        'general_editor',
        // 'plugin',
        // 'user',
        // 'theme',
        // 'language',
        // 'setting',
      ])->description(__('admin_messages.teams.general_editor_description'));

      Jetstream::role('demo', __('admin_messages.user.demo'), [//デモモード
        'read',
//        'create',
        'update',
//        'delete',
        'demo',
        'plugin',
        'user',
        'theme',
        'language',
        'setting',
      ])->description(__('admin_messages.teams.demo_description'));

    }
}
