<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();
        $this->call( UserTableSeeder::class );
        $this->call( FormBlocksTableSeeder::class );
        $this->call( ChoicesTableSeeder::class );
        $this->call( FormsTableSeeder::class );
        $this->call( FormItemsTableSeeder::class );
        $this->call( TeamsTableSeeder::class );
     
    }
}
