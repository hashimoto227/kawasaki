<?php

namespace Database\Seeders;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Seeder;

class TeamsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table( 'teams' )
        ->insert( 
          [ //setting時に予めteamを作成しておく
            'id'                                         => 1,
            'name'                                       => 'easy_mail',
            'user_id'                                    => 0,//owner不在のチームにする
            'personal_team'                              => 0,
            'created_at'                                 => now(),
            'updated_at'                                 => now(),
          ]
          );
    }
}
