<footer id="footer">
  @isset($append['in_fixed_bottom_top']){!! $append['in_fixed_bottom_top'] !!}@endisset
  <p id="copyright">&copy; 2020 EasyMail All Rights Reserved.</p>
  @isset($append['in_fixed_bottom_bottom']){!! $append['in_fixed_bottom_bottom'] !!}@endisset
</footer><!-- /#footer -->
