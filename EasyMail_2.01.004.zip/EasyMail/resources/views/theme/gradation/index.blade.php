@extends("theme.{$data->theme_name}.layout")
@section('content')
  @include("theme.{$data->theme_name}.form")
@endsection
@section('style')
@endsection
