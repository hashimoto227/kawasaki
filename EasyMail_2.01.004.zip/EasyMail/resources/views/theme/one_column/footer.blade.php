<footer class="footer">
  @isset($append['in_fixed_bottom_top']){!! $append['in_fixed_bottom_top'] !!}@endisset
  <p class="footer__copyright">&copy; 2020 EasyMail All Rights Reserved.</p>
  @isset($append['in_fixed_bottom_bottom']){!! $append['in_fixed_bottom_bottom'] !!}@endisset
</footer>
