@extends('admin.layout')
@section('title', __("admin_messages.page_title"))
@section('description', __("admin_messages.page_description"))
@section('content')
  <div class="container-fluid">
    <div class="col-12 mt-4">
      <h5 class="d-inline-block">
        {{ config("app.name") }}
      </h5>
      &nbsp;{{ config("app.version") }}
    </div>
    <div class=" mt-4 card-deck">
      <div class="col-lg-6">
        @isset($append['admin_upper_blog']){!! $append['admin_upper_blog'] !!}@endisset
        <div class="card mb-4">
          <div class="card-header">
            <img src="{{ config('app.public_url') }}/images/admin/blog_icon.svg" class="news_icon">
            &nbsp;&nbsp;Blog
            <a href="{{__('admin_messages.easymail_url')}}/blog/" target="_blank">
              <span><i class="fa-solid fa-arrow-up-right-from-square" style="float:right; padding-top: 6px;"></i></span>
            </a>
          </div>
          <div class="card-body">
            @foreach($blog_ar as $blog)
              <div class="row mt-3">
                <div class="col-3 text-center">{{ date("Y/m/d", strtotime($blog->date)) }}</div>
                <div class="col-9">
                  <a href="{{ $blog->link }}" aria-expanded="false" aria-controls="collapseExample" target="_blank">
                  {{ $blog->title->rendered }}
                  </a>
                  <div class="collapse" id="collapseExample{{$loop->index}}">
                    <div class="card card-body">
                    {{ $blog->content->rendered }}
                    </div>
                  </div>
                </div>
              </div>
            @endforeach
          </div>
        </div>
      </div>
      <div class="col-lg-6">
        @isset($append['admin_upper_news']){!! $append['admin_upper_news'] !!}@endisset
        <div class="card mb-4">
          <div class="card-header">
            <img src="{{ config('app.public_url') }}/images/admin/news_icon.svg" class="news_icon">
            &nbsp;&nbsp;News
            <a href="{{__('admin_messages.easymail_url')}}/news/" target="_blank">
              <span><i class="fa-solid fa-arrow-up-right-from-square" style="float:right; padding-top: 6px;"></i></span>
            </a>
          </div>
          <div class="card-body">
            @foreach($news_ar as $news)
              <div class="row mt-3">
                <div class="col-3 text-center">{{ date("Y/m/d", strtotime($news->date)) }}</div>
                <div class="col-9">
                  <a href="{{ $news->url }}" aria-expanded="false" aria-controls="collapseExample" target="_blank">
                    {!! $news->title !!}
                  </a>
                  <div class="collapse" id="collapseExample{{$loop->index}}">
                    <div class="card card-body">
                      {!! $news->content !!}
                    </div>
                  </div>
                </div>
              </div>
            @endforeach
          </div>
        </div>
      </div>
    
    </div>
  </div>
  <div class="container-fluid">

  </div>
  @isset($append['admin_top_bottom_section']){!! $append['admin_top_bottom_section'] !!}@endisset
@endsection
