<!-- Modal -->
<div id="registConfModal" class="modal fade">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<div class="title" id="registConfModalTitle">{{ __("admin_messages.confirm_regist") }}</div>
</div>
<div class="modal-body" id="registConfModalBody">

</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-dismiss="modal">{{ __("admin_messages.no") }}</button>
<button type="button" class="btn btn-primary btn-yes">{{ __("admin_messages.no") }}</button>
</div>
</div>
</div>
</div>
<!-- /Modal -->
