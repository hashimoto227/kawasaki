# EasyMail2.0 Plugin zip file temporary storage
[https://ezy-mail.jp](https://ezy-mail.jp)

## Setup and Document

EasyMail document is [here](https://ezy-mail.jp/document).

## License

The EasyMail is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).

