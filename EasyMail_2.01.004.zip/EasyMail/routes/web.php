<?php

use App\Http\Controllers\AdminController;
use Illuminate\Support\Facades\Route;
use App\Library\Common;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\AttachFileController;
use App\Http\Controllers\FormBlockController;
use App\Http\Controllers\FormController;
use App\Http\Controllers\FormItemController;
use App\Http\Controllers\HistoryController;
use App\Http\Controllers\LanguageController;
use App\Http\Controllers\LanguageFileController;
use App\Http\Controllers\PluginController;
use App\Http\Controllers\ForgotPasswordController;
use App\Http\Controllers\ThemeController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\SetUpController;
use GuzzleHttp\Middleware;
use Illuminate\Http\Request;

if (App::environment('production') || App::environment('staging')) {
     URL::forceScheme('https');
 };
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/***************************************************************
 * setup
 ***************************************************************/
Route::resource('setup', SetupController::class);
Route::get('/setup/{language}', [SetupController::class, 'setupSwitchLanguage'])
     ->name('setup.switch_language');


/***************************************************************
 * dash board
 ***************************************************************/
Route::middleware(['auth:sanctum', config('jetstream.auth_session'), 'verified'])
     ->group(function () {
          Route::get('/admin/dashboard', function () {
               return view('dashboard');
          })->name('admin.dashboard'); //  TODO 一時的に表示。公開時には削除
          Route::get('/admin/top', [AdminController::class, 'index'])->name('dashboard');
     });


/*****************************************************************
 * 管理者
 ****************************************************************/
Route::group(
     [
          'middleware' => ['auth:sanctum', config('jetstream.auth_session'), 'verified'],
          'prefix'     => 'admin', 'as' => 'admin.'
     ],

     function () {
          Route::post('/top', [AdminController::class, 'index'])
               ->name('top');

          /**
           * form
           */
          Route::resource('form', FormController::class);
          Route::resource('form', FormController::class)//デモモード用
               ->middleware(['demomode_auth:demo'])
               ->only( 'store' , 'update' , 'destroy' );
          Route::get('/form/copy/{id}', [FormController::class, 'copy'])
               ->middleware(['demomode_auth:demo'])
               ->name('form.copy');

          /**
           * form_block
           */
          Route::resource('form_block', FormBlockController::class);
          Route::resource('form_block', FormBlockController::class)//デモモード用
               ->middleware(['demomode_auth:demo'])
               ->only( 'store' , 'update' , 'destroy');
          Route::get('form_block/copy/{id}', [FormBlockController::class, 'copy'])
               ->middleware(['demomode_auth:demo'])
               ->name('form_block.copy');

          /**
           * form_item
           */
          Route::resource('form_item', FormItemController::class);
          Route::resource('form_item', FormItemController::class)//デモモード用
               ->middleware(['demomode_auth:demo'])
               ->only( 'store' , 'update' , 'destroy');


          /**
           * rew_pass
           */
          Route::get('/rew_pass', [SettingController::class, 'rew_pass'])
               ->name('rew_pass');
          Route::post('/rew_pass', [SettingController::class, 'pass_update'])
               ->middleware([ 'demomode_auth:demo'])
               ->name('rew_pass_update');

          /**
           * history
           */
          Route::resource('history', HistoryController::class, ['except' => ['show']]);
          Route::resource('history', HistoryController::class)//デモモード用
               ->middleware([ 'demomode_auth:demo'])
               ->only( 'store' , 'updata' , 'destroy');
          Route::match(['get', 'post'], '/history/list_form', [HistoryController::class, 'list_in_form'])
               ->name('history.list_in_form');

          /**
           * attach_file
           */
          Route::get('/attach_file/index', [AttachFileController::class, 'index'])
               ->name('attach_file.index');
          Route::post('/attach_file/destroy', [AttachFileController::class, 'destroy'])
               ->middleware(['demomode_auth:demo'])
               ->name('attach_file.destroy');
          Route::get('/attach_file/view/{file_name}', [AttachFileController::class, 'getfile'])
               ->middleware(['demomode_auth:demo'])
               ->name('attach_file.getfile');

          /**
           * dash board language
           */
          Route::get('/switch_language/{language}', [LanguageController::class, 'switchLang'])
               ->name('switch_language');

          /**
           * CSV
           */
          Route::get('/csv', [HistoryController::class, 'csv_download'])
               ->name('csv');

          /**
           * plugin
           */
          Route::get('/plugin/search', [PluginController::class, 'search'])
               ->middleware(['dashboard_auth:plugin'])
               ->name('plugin.search');
          Route::get('/plugin', [PluginController::class, 'index'])
               ->middleware(['dashboard_auth:plugin'])
               ->name('plugin.list');
          Route::post('/plugin/activation', [PluginController::class, 'activation'])
               ->middleware(['dashboard_auth:plugin'])
               ->middleware(['demomode_auth:demo'])
               ->name('plugin.activation');
          Route::post('/plugin/disable', [PluginController::class, 'disable'])
               ->middleware(['dashboard_auth:plugin'])
               ->name('plugin.disable');
          Route::post('/plugin/install', [PluginController::class, 'install'])
               ->middleware(['dashboard_auth:plugin'])
               ->middleware(['demomode_auth:demo'])
               ->name('plugin.install');
          Route::post('/plugin/uninstall', [PluginController::class, 'uninstall'])
               ->middleware(['dashboard_auth:plugin'])
               ->middleware(['demomode_auth:demo'])
               ->name('plugin.uninstall');
          Route::post('/plugin/update', [PluginController::class, 'update'])
               ->middleware(['dashboard_auth:plugin'])
               ->middleware(['demomode_auth:demo'])
               ->name('plugin.update');
          Route::post('/plugin/description', [PluginController::class, 'description'])
               ->middleware(['dashboard_auth:plugin'])
               ->name('plugin.description');
          Route::post('/plugin/search/description', [PluginController::class, 'search_description'])
               ->middleware(['dashboard_auth:plugin'])
               ->name('plugin.search_description');

          /**
           * theme
           */
          //     Route::resource('theme', ThemeController::class);
          Route::get('/theme', [ThemeController::class, 'index'])
               ->middleware(['dashboard_auth:theme'])
               ->name('theme.index');

          Route::get('/theme/{theme_name}', [ThemeController::class, 'show'])
               ->middleware(['dashboard_auth:theme'])
               ->name('theme.show');

          Route::post('/theme', [ThemeController::class, 'update'])
               ->middleware(['dashboard_auth:theme'])
               ->middleware(['demomode_auth:demo'])
               ->name('theme.update');

          /**
           * language file
           */
          //     Route::resource('language_file', LanguageFileController::class);
          Route::get('/language_file', [LanguageFileController::class, 'index'])
               ->middleware(['dashboard_auth:language'])
               ->name('language_file.index');

          Route::get('/language_file/{lang_name}', [LanguageFileController::class, 'show'])
               ->middleware(['dashboard_auth:language'])
               ->name('language_file.show');

          Route::post('/language_file', [LanguageFileController::class, 'update'])
               ->middleware(['dashboard_auth:language'])
               ->name('language_file.update');

          /**
           * db_setting
           */
          //     Route::resource('setting', SettingController::class);
          Route::get('/setting', [SettingController::class, 'index'])
               ->middleware(['dashboard_auth:setting'])
               ->name('setting.index');

          Route::post('/setting', [SettingController::class, 'update'])
               ->middleware(['demomode_auth:demo'])
               ->name('setting.update');

          /**
           * Users
           */
          Route::resource('users', UserController::class)
               ->middleware(['dashboard_auth:user']);
          Route::resource('users', UserController::class)//デモモード用
               ->middleware(['demomode_auth:demo'])
               ->only( 'store' , 'update' , 'destroy');
     }
);

/****************************************************************
 * フロント
 ****************************************************************/
Route::post('/thanks', [IndexController::class, 'thanks'])
     ->name('index.thanks');
Route::post('/{url}/thanks', [IndexController::class, 'thanks'])
     ->name('index.thanksurl');
Route::post('/send', [IndexController::class, 'send'])
     ->name('index.send');
Route::post('/{url}/send', [IndexController::class, 'send'])
     ->name('index.send.url');
Route::post('/', [IndexController::class, 'index'])
     ->name('post_index');
Route::post('/{url}', [IndexController::class, 'index'])
     ->name('post_index.url');
Route::get('/{url}', [IndexController::class, 'index'])
     ->name('index.url');
Route::get('/', [IndexController::class, 'index'])
     ->name('index');

/***************************************************************
 * resource folderから画像を取得
 ***************************************************************/
Route::get(
     '/resources/views/theme/{theme}/{filename}',
     function (Request $request) {
          $path = resource_path() . '/views/theme/' . $request->theme . '/' . $request->filename;

          if (!File::exists($path)) {
               return response()->json(['message' => 'Image not found.'], 404);
          }

          $file = File::get($path);
          $type = File::mimeType($path);

          $response = Response::make($file, 200);
          $response->header("Content-Type", $type);

          return $response;
     }
);

/***************************************************************
 * resource folderからCSS/JS取得
 ***************************************************************/
Route::get(
     '/resources/views/theme/{theme}/{folder}/{filename}',
     function (Request $request) {
          $path = resource_path() . '/views/theme/' . $request->theme . '/' . $request->folder . '/' . $request->filename;

          if (!File::exists($path)) {
               return response()->json(['message' => 'Image not found.'], 404);
          }

          $file = File::get($path);

          $file_info = pathinfo($request->filename);
          $file_type = $file_info['extension'];
          if ($file_type == 'css') {
               $type = 'text/css';
          } else {
               $type = 'application/javascript';
          }
          $response = Response::make($file, 200);
          $response->header("Content-Type", $type);
          return $response;
     }
);
